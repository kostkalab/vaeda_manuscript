library(testthat)
library(DoubletCollection)

test_check("DoubletCollection")
